import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import javax.swing.JOptionPane;
import javax.swing.text.html.HTML;
import java.util.ArrayList;
import java.util.List;

public class facebook {
    public static void main(String[] args) {

        facebook();
    }


    public static void facebook() {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver WDname = new ChromeDriver();

        WDname.get("https://facebook.com");
        WebElement email = WDname.findElement(By.id("email"));
        email.sendKeys("please enter your email");     //enter your facebook address

        WebElement password = WDname.findElement(By.id("pass"));
        password.sendKeys("enter your password here");  //enter your password here

        WebElement login = WDname.findElement(By.id("loginbutton"));
        login.click();

        WebElement notification1 = WDname.findElement(By.id("u_0_5"));
        String notificationMess = notification1.getText();
        WebElement notification2 = WDname.findElement(By.id("notificationsCountValue"));
        String notificationNum = notification2.getText();

         System.out.print("you have got " +notificationNum +" new notifications");

         String result = "you have got " +notificationNum +" new notifications";
         JOptionPane.showMessageDialog(null,result);

    }
    

}